@tool
extends EditorPlugin
class_name EditorFiniteStateMachine

const main_screen = preload("res://addons/cheesy-ai/scenes/main_screen.tscn")

static var main_panel: Control

func _ready() -> void:
	BehaviorNode._fsmnode = main_panel

func _enter_tree() -> void:
	main_panel = main_screen.instantiate()
	BehaviorNode._fsmnode = main_panel
	get_editor_interface().get_editor_main_screen().add_child(main_panel)
	_make_visible(false)
	add_custom_type("Resource", "Resource", load("res://addons/cheesy-ai/resources/behavior_tree.gd"), load("res://addons/cheesy-ai/icons/behavior_tree.svg"))


func _exit_tree() -> void:
	if main_panel:
		main_panel.queue_free()

func _has_main_screen() -> bool:
	return true

func _make_visible(visibility: bool) -> void:
	if main_panel:
		main_panel.visible = visibility

func _get_plugin_name() -> String:
	return "FSM"
	
func _get_plugin_icon() -> Texture2D:
	return preload("res://addons/cheesy-ai/icons/editor_icon.svg")
