@tool
@icon("res://addons/cheesy-ai/icons/behavior_node.svg")
extends Node
class_name BehaviorNode

static var _fsmnode: Control = null
static var _plugin: EditorFiniteStateMachine = null

@export_tool_button("Edit Behavior Tree") var edit_button = _edit_behavior_tree
@export var actor: Node
@export var black_board: Blackboard
@export var behavior_tree: BehaviorTree
@export_enum("Idle", "Physics") var process: String = "Idle"

func _edit_behavior_tree() -> void:
	if Engine.is_editor_hint() == true:
		EditorInterface.set_main_screen_editor("FSM")
		#var interfaces: Array = EditorInterface.get_editor_main_screen().get_children()
		#for i in interfaces:
			#if i.name == "FiniteStateMachine":
				#i.visible = true
			#else:
				#i.visible = false
	
func _process(delta: float) -> void:
	if process == "Idle" and Engine.is_editor_hint() == false:
		if behavior_tree != null:
			behavior_tree._tick(actor, black_board, delta)
			
func _physics_process(delta: float) -> void:
	if process == "Physics" and Engine.is_editor_hint() == false:
		if behavior_tree != null:
			behavior_tree._tick(actor, black_board, delta)
