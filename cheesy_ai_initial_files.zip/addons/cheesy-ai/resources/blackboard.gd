@tool
@icon("res://addons/cheesy-ai/icons/blackboard.svg")
extends BehaviorTree
class_name Blackboard

func _get_child_limit() -> int:
	return 0
