@tool
@icon("res://addons/cheesy-ai/icons/composition.svg")
extends BehaviorTree
class_name Composition

var focused_index: int = -1

func _get_child_limit() -> int:
	return -1
