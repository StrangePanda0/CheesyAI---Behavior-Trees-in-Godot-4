@tool
@icon("res://addons/cheesy-ai/icons/action.svg")
extends BehaviorTree
class_name Action

func _tick(actor: Node, blackboard, delta: float) -> int:
	var state: int = RUNNING
	return state

func _get_child_limit() -> int:
	return 0
