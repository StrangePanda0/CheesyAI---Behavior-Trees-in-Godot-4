@tool
@icon("res://addons/cheesy-ai/icons/behavior_tree.svg")
extends Resource
class_name BehaviorTree

const IDLE: int = 0
const RUNNING: int = 1
const SUCCESS: int = 2
const FAILURE: int = 3

@export var children: Array[BehaviorTree]
var name: String

func _tick(actor: Node, blackboard, delta: float) -> int:
	for i: BehaviorTree in children:
		i._tick(actor, blackboard, delta)
	return SUCCESS
 
func _get_child_limit() -> int:
	return 1
