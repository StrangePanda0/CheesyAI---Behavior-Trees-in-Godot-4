@tool
extends TabContainer

const treeicon = preload("res://addons/cheesy-ai/icons/editor_mode_tree.svg")
const blackboardicon = preload("res://addons/cheesy-ai/icons/editor_mode_blackboard.svg")
const graphicon = preload("res://addons/cheesy-ai/icons/editor_mode_graph.svg")
const icons: String = "res://addons/cheesy-ai/icons/"
const scripts: String = "res://addons/cheesy-ai/resources/"

@export var resource_lists: EditorFSMClassList

@onready var tree_tab: HSplitContainer = $Tree
@onready var tree_tree: Tree = $Tree/ColorRect/Tree
@onready var tree_resources_tree: Tree = $Tree/Resources

var current_data: BehaviorTree
var current_data_array: Dictionary[TreeItem, BehaviorTree]
var current_tree_item_array: Array[TreeItem]
var drag_data: TreeItem
var double_click: bool = false
var data_path: String = ""
var core_resources: Array[String] = ["BehaviorTree", "Composition", "Action", "Condition", "Decoration", "Reaction"]

func _process(delta: float) -> void:
	
	size = get_parent_control().get_parent().size
	
	tree_tab.split_offset = (size.x - 300)

func _ready() -> void:
	resource_lists = EditorFSMClassList.new()
	current_data = BehaviorTree.new()
	await  current_data
	await resource_lists
	tree_tree.clear()
	tree_resources_tree.clear()
	current_data_array.clear()
	
	set_tab_icon(0, treeicon)
	set_tab_icon(1, blackboardicon)
	set_tab_icon(2, graphicon)
	
	var root: TreeItem = tree_tree.create_item()
	
	root.set_text(0, "Root")
	root.set_icon(0, preload("res://addons/cheesy-ai/icons/behavior_tree.svg"))
	current_data_array[root] = resource_lists.resource_list.get("behavior_tree").duplicate(true)
	
	
	_load_resource_tree_item()
	
func _add_tree_item(idx: int = -1, icon: Texture2D = null, text: String = "") -> void:
	var new_item = tree_tree.get_selected().create_child()

func _load_resource_tree_item() -> void:
	var button_icon: Texture2D = load("res://addons/cheesy-ai/icons/editor_add.svg")
	var edit_icon: Texture2D = load("res://addons/cheesy-ai/icons/editor_edit.svg")
	var edit_info_icon: Texture2D = load("res://addons/cheesy-ai/icons/editor_information.svg")
	tree_resources_tree.clear()
	
	var root: TreeItem = tree_resources_tree.create_item()
	root.set_icon(0, load("res://addons/cheesy-ai/icons/behavior_tree.svg"))
	root.set_text(0, "Root")
	
	var composition_root: TreeItem = tree_resources_tree.create_item(tree_resources_tree.get_root())
	composition_root.set_icon(0, load("res://addons/cheesy-ai/icons/composition.svg"))
	composition_root.set_text(0, "Composition")
	var action_root: TreeItem = tree_resources_tree.create_item(tree_resources_tree.get_root())
	action_root.set_icon(0, load("res://addons/cheesy-ai/icons/action.svg"))
	action_root.set_text(0, "Action")
	var condition_root: TreeItem = tree_resources_tree.create_item(tree_resources_tree.get_root())
	condition_root.set_icon(0, load("res://addons/cheesy-ai/icons/condition.svg"))
	condition_root.set_text(0, "Condition")
	var decoration_root: TreeItem = tree_resources_tree.create_item(tree_resources_tree.get_root())
	decoration_root.set_icon(0, load("res://addons/cheesy-ai/icons/decoration.svg"))
	decoration_root.set_text(0, "Decoration")
	var reaction_root: TreeItem = tree_resources_tree.create_item(tree_resources_tree.get_root())
	reaction_root.set_icon(0, load("res://addons/cheesy-ai/icons/reaction.svg"))
	reaction_root.set_text(0, "Reaction")
	var other_root: TreeItem = tree_resources_tree.create_item(tree_resources_tree.get_root())
	other_root.set_icon(0, load("res://addons/cheesy-ai/icons/others.svg"))
	other_root.set_text(0, "Others")
	
	for i: String in resource_lists.resource_list:
		if not i.to_pascal_case() in core_resources:
			var new: TreeItem
			if i.begins_with("composition"):
				new = composition_root.create_child()
				new.set_icon(0, resource_lists.resource_icon_list.get(i))
			elif i.begins_with("action"):
				new = action_root.create_child()
				new.set_icon(0, resource_lists.resource_icon_list.get(i))
			elif i.begins_with("condition"):
				new = condition_root.create_child()
				new.set_icon(0, resource_lists.resource_icon_list.get(i))
			elif i.begins_with("decoration"):
				new = decoration_root.create_child()
				new.set_icon(0, resource_lists.resource_icon_list.get(i))
			elif i.begins_with("reaction"):
				new = reaction_root.create_child()
				new.set_icon(0, resource_lists.resource_icon_list.get(i))
			else:
				new = other_root.create_child()
				new.set_icon(0, resource_lists.resource_icon_list.get(i))
			
			new.set_text(0, i.to_pascal_case())
			new.add_button(0, button_icon, -1, false, "Add")
			new.add_button(0, edit_info_icon, -1, true, "Information")
			new.add_button(0, edit_icon, -1, false, "Open Script")
			
			current_tree_item_array.append(new)

func _on_tree_cell_selected() -> void:
	EditorInterface.inspect_object(current_data_array[tree_tree.get_selected()])
	var object: BehaviorTree = current_data_array[tree_tree.get_selected()]
	if object._get_child_limit() >= 0:
		if object._get_child_limit() > tree_tree.get_selected().get_child_count():
			for i: TreeItem in current_tree_item_array:
				i.set_button_disabled(0, 0, false)
		else:
			for i: TreeItem in current_tree_item_array:
				i.set_button_disabled(0, 0, true)
	else:
		for i: TreeItem in current_tree_item_array:
			i.set_button_disabled(0, 0, false)
	

func edit_resource(behavior_tree: BehaviorTree) -> void:
	current_data = behavior_tree
	
func _get_tree_item_path(tree_item: TreeItem) -> String:
	var parent_item: TreeItem = tree_item.get_parent()
	var path: String = ""
	path = "{0}".format([tree_item.get_index()])
	if tree_item.get_text(0) == "Root":
		return ""
	while parent_item.get_text(0) != "Root":
		path = "{0},{1}".format([parent_item.get_index(), path])
		parent_item = parent_item.get_parent()
	return path

func _on_resources_button_clicked(item: TreeItem, column: int, id: int, mouse_button_index: int) -> void:
	if id == 0:
		if tree_tree.get_selected() != null and not item.get_text(0) in core_resources:
			var new_item: TreeItem = tree_tree.create_item(tree_tree.get_selected())
			new_item.set_icon(0, item.get_icon(0))
			new_item.set_text(0, item.get_text(0))
			current_data_array[new_item] = resource_lists.resource_list[item.get_text(0).to_snake_case()].duplicate(true)
	elif id == 2:
		EditorInterface.edit_script(resource_lists.resource_list[item.get_text(0).to_snake_case()].get_script())
		EditorInterface.set_main_screen_editor("Script")
	

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.pressed == true:
			if event.button_index == MOUSE_BUTTON_LEFT:
				if event.double_click == true:
					if tree_tree.has_focus():
						if tree_tree.get_selected() != null:
							if tree_tree.get_selected().get_text(0) != "Root":
								tree_tree.get_selected().set_editable(0, true)
				

func _on_tree_item_edited() -> void:
	pass
