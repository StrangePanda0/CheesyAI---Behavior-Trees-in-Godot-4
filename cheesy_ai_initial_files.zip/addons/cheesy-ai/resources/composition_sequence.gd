@tool
@icon("res://addons/cheesy-ai/icons/composition_sequence.svg")
extends Composition
class_name CompositionSequence

func _tick(actor: Node, blackboard: Blackboard, delta: float) -> int:
	var state: int = IDLE
	if focused_index >= 0:
		state = children[focused_index]._tick(actor, blackboard, delta)
		if state == RUNNING:
			return state
		else:
			focused_index = -1
			return state
	for i: int in range(children.size()):
		state = children[i]._tick(actor, blackboard, delta)
		if state == RUNNING:
			focused_index = i
			break
			return state
		elif state == FAILURE:
			break
			return state
	return SUCCESS
