extends Resource
class_name EditorFSMClassList

var icons: String = "res://addons/cheesy-ai/icons/"
var scripts: String = "res://addons/cheesy-ai/resources/"

var resource_list: Dictionary[String, BehaviorTree]
var resource_icon_list: Dictionary[String, Texture2D]

func _init() -> void:
	resource_list.clear()
	resource_icon_list.clear()
	var directory_access: DirAccess = DirAccess.open(scripts)
	directory_access.list_dir_begin()
	var file: String = directory_access.get_next()
	while file != "":
		if file.ends_with(".gd") == false:
			file = directory_access.get_next()
			continue
		var path: String = scripts + file
		resource_list[file.replace(".gd", "")] = ResourceLoader.load(path).new()
		var icon_path: String = icons + file.replace(".gd", "") + ".svg"
		var icon_resource = ResourceLoader.load(icon_path)
		if icon_resource:
			resource_icon_list[file.replace(".gd", "")] = icon_resource
		file = directory_access.get_next()
		
		
